<?php return array (
  'admin-credit' => 'App\\Http\\Livewire\\AdminCredit',
  'admin-data' => 'App\\Http\\Livewire\\AdminData',
  'admin-edit-course' => 'App\\Http\\Livewire\\AdminEditCourse',
  'admin-edit-lesson' => 'App\\Http\\Livewire\\AdminEditLesson',
  'admin-edit-section' => 'App\\Http\\Livewire\\AdminEditSection',
  'admin-lesson' => 'App\\Http\\Livewire\\AdminLesson',
  'admin-question' => 'App\\Http\\Livewire\\AdminQuestion',
  'admin-references' => 'App\\Http\\Livewire\\AdminReferences',
  'admin-resource' => 'App\\Http\\Livewire\\AdminResource',
  'admin-section' => 'App\\Http\\Livewire\\AdminSection',
  'admin-users' => 'App\\Http\\Livewire\\AdminUsers',
  'register-zone' => 'App\\Http\\Livewire\\RegisterZone',
);