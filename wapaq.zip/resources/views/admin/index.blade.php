@extends('adminlte::page')

@section('title', 'Panel Admin')

@section('content_header')
  <h1> Panel Admin</h1>
@stop

@section('content')
  <p> welcome to the admins pannel </p>
@stop

@section('css')

@stop

@section('js')
  <script>console.log('Hi');</script>
@stop
