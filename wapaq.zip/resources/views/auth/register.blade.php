<x-app-layout>

    @livewire('register-zone')


</x-app-layout>
