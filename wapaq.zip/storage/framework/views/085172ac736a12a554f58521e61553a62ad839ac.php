

<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> Administrar Secciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1 class="fs-4">
                Editando: <?php echo e($course->name); ?>

            </h1>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.course.update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="id" value="<?php echo e($course->id); ?>" hidden>
                <div class="form-group">
                    <label for="name">Nombre nuevo</label>
                    <input type="text" class="form-control" name="name" placeholder="Coloque el nombre" required value="<?php echo e($course->name); ?>">
                </div>
                <button type="submit" class="mt-4 btn btn-primary">Actualizar</button>
            </form>
        </div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mt-4 mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-4 mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    </div>

    <h3>Editar Secciones</h3>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-edit-course',['course_id'=>$course_id])->html();
} elseif ($_instance->childHasBeenRendered('nqionmG')) {
    $componentId = $_instance->getRenderedChildComponentId('nqionmG');
    $componentTag = $_instance->getRenderedChildComponentTagName('nqionmG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('nqionmG');
} else {
    $response = \Livewire\Livewire::mount('admin-edit-course',['course_id'=>$course_id]);
    $html = $response->html();
    $_instance->logRenderedChild('nqionmG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/course/edit.blade.php ENDPATH**/ ?>