<div class="card">
    <div class="card-header">
        <input wire:keydown:"limpiar_page" wire:model="search" class="form-control w-100" placeholder="Escriba un nombre ...">
    </div>
    <table class="table table-dark">
        <thead>
          <tr>
            <th class="col-1" scope="col">#</th>
            <th class="col-2">Name</th>
            <th class="col-md-1">Lección</th>
            <th class="col-md-1">Evaluacion</th>
            <th class="col-md-1">Rol</th>
            <th class="col-md-1">Admin/user</th>
            <th class="col-1">Eliminar user</th>


          </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <th scope="row"><?php echo e($user->id); ?></th>
                <td><?php echo e($user->name); ?></td>
                <td><?php echo e($user->lesson_now+1); ?></td>
                <td><?php echo e($user->usability>0?'Si':'No'); ?></td>
                <td><?php echo e(sizeof($user->roles)>0?'Admin':'Estudiante'); ?></td>
                <td>
                    <i class="fas fa-users-cog" style="color:cyan;"  wire:click="cambiarAdmin(<?php echo e($user->id); ?>)" ></i>
                </td>
                <td>
                    <i class="fas fa-user-times" style="color:red;"  wire:click="removeUser(<?php echo e($user->id); ?>)" ></i>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </tbody>
      </table>

      <?php echo e($users->links()); ?>

</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-users.blade.php ENDPATH**/ ?>