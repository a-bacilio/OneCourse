<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.lesson.create')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-plus"></i> Añadir Lección
            </button>
        </a>
    </div>
    <div class="card-header">
        <input wire:keydown:"limpiar_page" wire:model="search" class="form-control w-100" placeholder="Escriba un nombre ...">
    </div>
    <div class="card-body">
        <table class="table table-dark">
            <thead>
              <tr>
                <th class="col-1" scope="col">#</th>
                <th scope="col-2">Name</th>
                <th scope="col-1">Editar</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($lesson->id); ?></th>
                    <td><?php echo e($lesson->name); ?></td>
                    <td>
                        <a href="lesson/edit/<?php echo e($lesson->id); ?>" style="background-color:#00000000; border:none;" type="submit"><i class="fas fa-pencil-alt" style="color:yellow;"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($lessons->links()); ?>

    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-lesson.blade.php ENDPATH**/ ?>