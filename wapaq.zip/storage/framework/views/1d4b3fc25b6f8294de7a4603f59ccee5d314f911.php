<div class="card">
    <div class="card-body">
        <span class="">Lecciones en la seccion</span>
        <table class="table table-dark">
            <thead>
                <tr>
                    <th class="col-1" scope="col">#</th>
                    <th scope="col-2">Name</th>
                    <th scope="col-1">Retire</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($lesson->id); ?></th>
                        <td><?php echo e($lesson->name); ?></td>
                        <td>
                            <i wire:click="removelesson(<?php echo e($lesson->id); ?>)" style="color: yellow; margin:auto"
                                class="fas fa-arrow-circle-down"></i>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            No hay lecciones
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-body">
        <span class="">Lecciones disponibles</span>
        <table class="table table-dark">
            <thead>
                <tr>
                    <th class="col-1" scope="col">#</th>
                    <th scope="col-2">Name</th>
                    <th scope="col-1">Retire</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $lessons_nosection; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($lesson->id); ?></th>
                        <td><?php echo e($lesson->name); ?></td>
                        <td>
                            <i wire:click="addlesson(<?php echo e($lesson->id); ?>)" style="color: green; margin:auto"
                                class="fas fa-arrow-circle-up"></i>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            No hay lecciones
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-edit-section.blade.php ENDPATH**/ ?>