<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.resource.createimage')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-image"></i> Añadir Imagen
            </button>
        </a>
        <a href="<?php echo e(route('admin.resource.createvideo')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fab fa-youtube"></i> Añadir Video
            </button>
        </a>
    </div>
    <div class="card-header">
        <input wire:keydown:"limpiar_page" wire:model="search" class="form-control w-100" placeholder="Escriba un nombre ...">
    </div>
    <div class="card-body">
        <table class="table table-dark">
            <thead>
              <tr>
                <th class="col-1" scope="col">#</th>
                <th scope="col-2">Name</th>
                <th scope="col-2">Lección</th>
                <th scope="col-1">Tipo</th>
                <th scope="col-1">Muestra</th>
                <th scope="col-1"><br/></th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($resource->id); ?></th>
                    <td><?php echo e($resource->name); ?></td>
                    <td><?php echo e($resource->lesson_id); ?></td>
                    <td><?php echo e($resource->type); ?></td>
                    <?php if($resource->type=='video'): ?>
                        <td>
                            <a target="_blank" href="<?php echo e($resource->online_video->url); ?>">
                                ver video
                            </a>
                        </td>
                    <?php elseif($resource->type=='image'): ?>
                        <td>
                            <img style="max-width:3rem; max-height:3rem;object-fit:cover; margin-x:auto; width:full;" src="<?php echo e(asset($resource->image->url)); ?>"/>
                        </td>
                    <?php endif; ?>
                    <td>
                        <form method="POST" action="<?php echo e(route('admin.resource.destroyresource')); ?>">
                            <?php echo csrf_field(); ?>
                            <input name="id" value="<?php echo e($resource->id); ?>" hidden/>
                            <button style="background-color:#00000000; border:none;" type="submit"><i class="fas fa-trash-alt" style="color:red;"></i></button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($resources->links()); ?>

    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-resource.blade.php ENDPATH**/ ?>