<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col w-full h-full mx-auto my-auto lg:items-start max-w-7xl lg:flex-row">
        <article class="flex flex-col w-11/12 min-h-screen p-6 mx-auto my-10 bg-white rounded-lg shadow-xl">
            <h1 class="text-3xl font-bold">
                Preguntas frecuentes
            </h1>
            <article
                class="flex flex-col items-start justify-start p-6 mt-6 border-4 border-black border-dashed rounded-lg min-w-90">
                <?php $__empty_1 = true; $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>

                    <h2 class="text-xl font-bold">
                        <?php echo e($question->order); ?>. <?php echo e($question->question); ?>

                    </h2>
                    <h3 class="w-full p-3 mb-6 text-lg rounded-lg bg-sky-200">
                        <?php echo e($question->answer); ?>

                    </h3>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <h2 class="mb-6 text-sm font-bold">
                        No hay referencias
                    </h2>

                <?php endif; ?>
            </article>
        </article>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/questions.blade.php ENDPATH**/ ?>