<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1> Crear recursos</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="card">
    <div class="card-body">
        <form>
            <div class="form-group">
              <label for="name">Nombre</label>
              <input type="text" class="form-control" id="name" aria-describedby="emailHelp" placeholder="Enter email">
            </div>
            <div class="form-group" x-data="{ open: false }">
                <label for="type">Que tipo de recurso es?</label>
                <select class="form-control" id="type"  placeholder="Seleccion el tipo">
                    <option x-on:click="open = false" value="video">Video</option>
                    <option x-on:click="open = true" value="image">Image</option>
                </select>
                <span x-show="open">
                    Content...1
                </span>
                <span x-show="!open">
                    Content...2
                </span>
            </div>

            <button type="submit" class="btn btn-primary">Submit</button>
          </form>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
  <link rel="stylesheet" href="/css/admin_custom_css">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>console.log('Hi');</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/resource/create.blade.php ENDPATH**/ ?>