<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1> Panel Admin</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <p> welcome to the admins pannel </p>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>console.log('Hi');</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/index.blade.php ENDPATH**/ ?>