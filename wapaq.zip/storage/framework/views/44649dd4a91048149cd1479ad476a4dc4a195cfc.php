<style>
    @page  { margin:0px; }
    </style>
    <div style="margin:0;width:100%; height:100%;  background-position: center; background-repeat: no-repeat; background-size: 100% 100%; background-image:url(<?php echo e(asset($information->certificate_img)); ?>); ">
    <div style="position:absolute; top:<?php echo e($information->certificate_pos_y??'0'); ?>; left:<?php echo e($information->certificate_pos_x??'0'); ?>; font-size:<?php echo e($information->certificate_fontsize??'14px'); ?>"><?php echo e($user->name??"nombreusuario"); ?></div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/content/certificate.blade.php ENDPATH**/ ?>