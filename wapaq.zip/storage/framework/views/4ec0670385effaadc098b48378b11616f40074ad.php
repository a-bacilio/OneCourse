<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.credit.create')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-plus"></i> Añadir Creditos
            </button>
        </a>
    </div>
    <div class="card-header">
        <input wire:keydown:"limpiar_page" wire:model="search" class="form-control w-100"
            placeholder="Escriba un nombre ...">
    </div>
    <div class="card-body">
        <table class="table table-dark">
            <thead>
                <tr>
                    <th class="col-1" scope="col">Orden</th>
                    <th class="">Name</th>
                    <th class="">role</th>
                    <th class="col-2">description</th>
                    <th class="col-1">picture</th>
                    <th class="">id</th>
                    <th class="col-1">Accion</th>

                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($credit->order); ?></th>
                        <td><?php echo e($credit->name); ?></td>
                        <td><?php echo e($credit->role); ?></td>
                        <td><?php echo e($credit->description); ?></td>
                        <td><img style="width:50px;height:50px;" src="<?php echo e(asset($credit->picture)); ?>"  alt="<?php echo e($credit->name); ?>"></td>
                        <td><?php echo e($credit->id); ?></td>
                        <td class="flex-row d-flex" >
                            <div>
                                <i wire:click="removeCredit(<?php echo e($credit->id); ?>)" style="color:red;" class="ml-1 fas fa-trash"></i>
                                <a href="<?php echo e(route('admin.credit.edit',$credit->id)); ?>" class="ml-1"><i style="color:yellow;" class="fas fa-pencil-alt"></i></a>
                                <?php if($credit->order!==1): ?>
                                    <i style="color:blue;"  wire:click="moveCreditUp(<?php echo e($credit->id); ?>)" class="ml-1 fas fa-arrow-circle-up"></i>
                                <?php endif; ?>
                                <?php if($credit->order!==sizeof($credits)): ?>
                                    <i style="color:blue;" wire:click="moveCreditDown(<?php echo e($credit->id); ?>)" class="ml-1 fas fa-arrow-circle-down"></i>
                                <?php endif; ?>
                            </div>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="col-span-2">
                       <td colspan="2"> No hay elementos</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($credits->links()); ?>

    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-credit.blade.php ENDPATH**/ ?>