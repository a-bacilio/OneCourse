<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
        $lesson_now = $course->lessons[Auth::user()->lesson_now];
        $sus_qs=[
            [
                'value'=>'Pienso que usaria este sistema frecuentemente',
                'name'=>'sus1'
            ],
            [
                'value'=>'Encuentro el sistema simple',
                'name'=>'sus2'
            ],
            [
                'value'=>'El sistema fue facil de usar',
                'name'=>'sus3'
            ],
            [
                'value'=>'Necesito la ayudad de personal técnico para realizar las tareas',
                'name'=>'sus4'
            ],
            [
                'value'=>'Encontre que varias de las funciones estan bien integradas',
                'name'=>'sus5'
            ],
            [
                'value'=>'Encontre mucha consistencia en el sistema',
                'name'=>'sus6'
            ],
            [
                'value'=>'Pienso que este sistema seria facil de aprender',
                'name'=>'sus7'
            ],
            [
                'value'=>'Pienso que aprender a usar este sistema no seria ni una molestia',
                'name'=>'sus8'
            ],
            [
                'value'=>'Tengo confianza al usar este sistema',
                'name'=>'sus9'
            ],
            [
                'value'=>'No necesito aprender varias cosas antes de usar este sistema',
                'name'=>'sus10'
            ],
        ];
        $csuq_qs=[
            [
                'value'=>'En general estoy satisfecho  con lo facil que es utilizar este sitio web',
                'name'=>'csuq1'
            ],
            [
                'value'=>'Fue simple usar este sitio web',
                'name'=>'csuq2'
            ],
            [
                'value'=>'Soy capaz de completar los objetivos, utilizando el sistio web',
                'name'=>'csuq3'
            ],
            [
                'value'=>'Me siento comodo utilziando este sitio web',
                'name'=>'csuq4'
            ],
            [
                'value'=>'Fue fácil aprender a utilizar el sistema del sitio web',
                'name'=>'csuq5'
            ],
            [
                'value'=>'Creo que me volví experto rapidamente utilizando el sistema del sitio web',
                'name'=>'csuq6'
            ],
            [
                'value'=>'El sitio web muestra mensajes de error utilizando el sistema lo resuelvo facil y rapidamente',
                'name'=>'csuq7'
            ],
            [
                'value'=>'Cada vez que cometo un error en el sistema actual, lo resuelvo fácil y rápidamente',
                'name'=>'csuq8'
            ],
            [
                'value'=>'La  información (como  ayuda en  línea,  mensajes  en pantalla y otra documentación) que provee  este sitio web es clara',
                'name'=>'csuq9'
            ],
            [
                'value'=>'Es fácil encontrar  en el sitio  web la información que necesito.',
                'name'=>'csuq10'
            ],
            [
                'value'=>'La  información  que  proporciona  el  sitio  web  fue efectiva ayudándome a completar las tareas.',
                'name'=>'csuq11'
            ],
            [
                'value'=>'La organización de la información del sitio web en la pantalla fue clara.',
                'name'=>'csuq12'
            ],
            [
                'value'=>'La interfaz del sitio web fue placentera. ',
                'name'=>'csuq13'
            ],
            [
                'value'=>'Me gustó utilizar el sitio web.',
                'name'=>'csuq14'
            ],
            [
                'value'=>'El sitio web tuvo todas las herramientas que esperaba que tuviera.',
                'name'=>'csuq15'
            ],
            [
                'value'=>'En general, estuve satisfecho con el sitio web. ',
                'name'=>'csuq16'
            ],
        ];
    ?>
    <div class="p-2 mx-auto mt-5 max-w-7xl">
        <h1 class="text-3xl font-bold">Evaluación final</h1>

        <div class="grid w-full grid-cols-1 gap-6 my-5 sm:grid-cols-4">
            
            <article class="w-full col-span-1 p-5 bg-white rounded-lg sm:col-span-3">

                <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

                <h1 class="text-xl font-bold">1. Evaluación de usabilidad I (SUS)</h1>
                <form class="flex flex-col w-full" method="POST" action=<?php echo e(route('content.registerevaluation')); ?>>
                    <?php echo csrf_field(); ?>
                    <p>A continuación, del 1 al 5 que tanto de acuerdo se encuentra con los enunciados donde 1 es totalmente en desacuerdo y 5  es totalmente de aceurdo.</p>
                    <?php $__currentLoopData = $sus_qs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $sus_q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-row items-center w-full p-2 mt-5 border border-blue-900 rounded-lg justify between">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'w-full col-span-1','for' => ''.e($sus_q['name']).'','value' => ''.e($key+1).'. '.e($sus_q['value']).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full col-span-1','for' => ''.e($sus_q['name']).'','value' => ''.e($key+1).'. '.e($sus_q['value']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'float-right w-28','id' => ''.e($sus_q['name']).'','type' => 'number','min' => '0','max' => '5','name' => ''.e($sus_q['name']).'','value' => old($sus_q['name']),'required' => true,'autofocus' => true]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'float-right w-28','id' => ''.e($sus_q['name']).'','type' => 'number','min' => '0','max' => '5','name' => ''.e($sus_q['name']).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old($sus_q['name'])),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                <h1 class="mt-5 text-xl font-bold">2. Evaluación de usabilidad II (CSUQ)</h1>

                    <p>A continuación, del 1 al 7 que tanto de acuerdo se encuentra con los enunciados donde 1 es totalmente en desacuerdo y 7  es totalmente de aceurdo.</p>
                    <?php $__currentLoopData = $csuq_qs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $csuq_q): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex flex-row items-center w-full p-2 mt-5 border border-blue-900 rounded-lg justify between">
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.label','data' => ['class' => 'w-full col-span-1','for' => ''.e($csuq_q['name']).'','value' => ''.e($key+1).'. '.e($csuq_q['value']).'']]); ?>
<?php $component->withName('jet-label'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'w-full col-span-1','for' => ''.e($csuq_q['name']).'','value' => ''.e($key+1).'. '.e($csuq_q['value']).'']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                            <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.input','data' => ['class' => 'float-right w-28','id' => ''.e($csuq_q['name']).'','type' => 'number','min' => '0','max' => '5','name' => ''.e($csuq_q['name']).'','value' => old($csuq_q['name']),'required' => true,'autofocus' => true]]); ?>
<?php $component->withName('jet-input'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'float-right w-28','id' => ''.e($csuq_q['name']).'','type' => 'number','min' => '0','max' => '5','name' => ''.e($csuq_q['name']).'','value' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute(old($csuq_q['name'])),'required' => true,'autofocus' => true]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                    <button class="p-2 mx-auto my-10 text-white bg-blue-900 rounded-lg" type="submit">Enviar respuestas</button>
                </form>
            </article>






            

            <div class="flex flex-col w-full col-span-1 p-2 overflow-hidden text-xs bg-white rounded-lg">
                <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="my-2" x-data="{ open: false }">
                        <h3 class="p-2 font-bold text-white bg-blue-600 rounded-lg" x-on:click="open = ! open">
                            <?php echo e($key + 1); ?>. <?php echo e($section->name); ?> <i class="fas fa-caret-down"></i></h3>
                        <div class="w-full" x-show="open">
                            <?php if($section->lessons_count == 0): ?>
                                <div class="w-full p-2 mt-2 border rounded-lg">
                                    No hay lecciones
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($lesson->section_id == $section->id): ?>
                                        <form
                                            class="w-full rounded-lg p-2 mt-2 border <?php echo e($key <= Auth::user()->lesson_max ? 'text-black' : 'text-gray-400'); ?> <?php echo e($key == Auth::user()->lesson_now? 'bg-blue-400' : 'bg-blue-200'); ?>"
                                            method="POST" action=<?php echo e(route('content.updatespecific')); ?>>
                                            <?php echo csrf_field(); ?>
                                            <input value=<?php echo e($key); ?> name="lesson" hidden>
                                            <button class="text-left" type="submit">L.<?php echo e($key+1); ?> - <?php echo e($lesson->name); ?></button>
                                        </form>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="my-5">
                        No hay secciones aún
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->lesson_max==$course->lessons_count-1): ?>
                    <a href="<?php echo e(route('content.showevaluation')); ?>" class="w-full p-2 my-2 font-bold text-black bg-yellow-300 rounded-lg">Evaluacion final</a>
                <?php endif; ?>
                <?php if(Auth::user()->usability==1): ?>
                    <a href="<?php echo e(route('content.showcertification')); ?>" class="w-full p-2 my-2 font-bold text-black bg-purple-300 rounded-lg">Certificado</a>
                <?php endif; ?>
            </div>

        </div>


    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/content/evaluation.blade.php ENDPATH**/ ?>