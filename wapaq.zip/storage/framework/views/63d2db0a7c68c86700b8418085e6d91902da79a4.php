<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1>
        Configurar información del sitio
    </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-body">
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="welcome_title"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="welcome_title">Mensaje de bienvenida</label>
                        <input style="height:80%;" class="col-11 col-md-8" type="text" name="welcome_title" value="<?php echo e($information->welcome_title); ?>">
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar mensaje de
                        bienvenida</button>
                </div>
                <?php $__errorArgs = ['welcome_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="welcome_text_1"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="welcome_text_1">Texto de bienvenida 1</label>
                        <textarea style="height:80%;min-height:100px;" class="col-11 col-md-8" type="text" name="welcome_text_1">
                            <?php echo e($information->welcome_text_1); ?>

                        </textarea>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar texto de bienvenida 1</button>
                </div>
                <?php $__errorArgs = ['welcome_text_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="welcome_text_2"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="welcome_text_2">Texto de bienvenida 2</label>
                        <textarea style="height:80%;min-height:100px;" class="col-11 col-md-8" type="text" name="welcome_text_2">
                            <?php echo e($information->welcome_text_2); ?>

                        </textarea>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar texto de bienvenida 2</button>
                </div>
                <?php $__errorArgs = ['welcome_text_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="welcome_video"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="welcome_video">Iframe video de bienvenida</label>
                        <textarea style="height:80%;min-height:100px;" class="col-11 col-md-8" type="text" name="welcome_video">
                            <?php echo e($information->welcome_video); ?>

                        </textarea>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar video de bienvenida</button>
                </div>
                <?php $__errorArgs = ['welcome_video'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="end_title"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="end_title">Mensaje final</label>
                        <input style="height:80%;" class="col-11 col-md-8" type="text" name="end_title" value="<?php echo e($information->end_title); ?>">
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar mensaje final</button>
                </div>
                <?php $__errorArgs = ['end_title'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="end_text_1"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="end_text_1">Texto de salida 1</label>
                        <textarea style="height:80%;min-height:100px;" class="col-11 col-md-8" type="text" name="end_text_1">
                            <?php echo e($information->end_text_1); ?>

                        </textarea>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar texto de salida 1</button>
                </div>
                <?php $__errorArgs = ['end_text_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="end_text_2"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="end_text_2">Texto de salida 2</label>
                        <textarea style="height:80%;min-height:100px;" class="col-11 col-md-8" type="text" name="end_text_2">
                            <?php echo e($information->end_text_2); ?>

                        </textarea>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar texto de salida 2</button>
                </div>
                <?php $__errorArgs = ['end_text_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="logo"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="logo">Logo (recargar con ctrl+f5)</label>
                        <img style="width:70px; margin:1rem auto;" src="<?php echo e(asset('img/logo/logo.png')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="logo" placeholder="Seleccione una imagen"
                        accept="image/png" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar Logo (PNG)</button>
                </div>
                <?php $__errorArgs = ['logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="black_logo"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="black_logo">Logo oscuro (recargar con ctrl+f5)</label>
                        <img style="width:70px; margin:1rem auto;" src="<?php echo e(asset('img/logo/black_logo.png')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="black_logo" placeholder="Seleccione una imagen"
                        accept="image/png" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar logo oscuro (PNG)</button>
                </div>
                <?php $__errorArgs = ['black_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="white_logo"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="white_logo">Logo blanco (recargar con ctrl+f5)</label>
                        <img style="width:70px; margin:1rem auto; background-color:black;" src="<?php echo e(asset('img/logo/white_logo.png')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="white_logo" placeholder="Seleccione una imagen"
                        accept="image/png" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar logo blanco (PNG)</button>
                </div>
                <?php $__errorArgs = ['white_logo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="consent_img_1"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="consent_img_1">Pagina 1 del consentimiento informado (recargar con ctrl+f5)</label>
                        <img style="width:150px; margin:1rem auto; background-color:black;" src="<?php echo e(asset('img/consent/1.png')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="consent_img_1" placeholder="Seleccione una imagen"
                        accept="image/png" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar pagina 1 (PNG)</button>
                </div>
                <?php $__errorArgs = ['consent_img_1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="consent_img_2"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="consent_img_2">Pagina 2 del consentimiento informado (recargar con ctrl+f5)</label>
                        <img style="width:150px; margin:1rem auto; background-color:black;" src="<?php echo e(asset('img/consent/2.png')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="consent_img_2" placeholder="Seleccione una imagen"
                        accept="image/png" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar pagina 2 (PNG)</button>
                </div>
                <?php $__errorArgs = ['consent_img_2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="consent_img_3"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="consent_img_3">Pagina 3 del consentimiento informado (recargar con ctrl+f5)</label>
                        <img style="width:150px; margin:1rem auto; background-color:black;" src="<?php echo e(asset('img/consent/3.png')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="consent_img_3" placeholder="Seleccione una imagen"
                        accept="image/png" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar pagina 3 (PNG)</button>
                </div>
                <?php $__errorArgs = ['consent_img_3'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" enctype="multipart/form-data" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="certificate_img"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="certificate_img">Imagen de fondo del certificado</label>
                        <img style="width:150px; margin:1rem auto; background-color:black;" src="<?php echo e(asset('img/certificate/diploma.jpg')); ?>" />
                        <input type="file" style="object-fit: cover;" class="ml-3 mr-3 form-control-file" name="certificate_img" placeholder="Seleccione una imagen"
                        accept="image/jpg" required>
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar certificado (JPG)</button>
                </div>
                <?php $__errorArgs = ['certificate_img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="certificate_fontsize"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="certificate_fontsize">Tamaño de fuente</label>
                        <input style="height:80%;" class="col-11 col-md-8" type="text" name="certificate_fontsize" value="<?php echo e($information->certificate_fontsize); ?>">
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar tamaño de fuente</button>
                </div>
                <?php $__errorArgs = ['certificate_fontsize'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="certificate_pos_x"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="certificate_pos_x">Distancia del borde izquierdo</label>
                        <input style="height:80%;" class="col-11 col-md-8" type="text" name="certificate_pos_x" value="<?php echo e($information->certificate_pos_x); ?>">
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar distancia del borde izquierdo (1px, 1rem, 1inch, 1cm)</button>
                </div>
                <?php $__errorArgs = ['certificate_pos_x'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
            <form class="mb-5 d-flex flex-column" method="POST" action="<?php echo e(route('admin.information.update')); ?>">
                <?php echo csrf_field(); ?>
                <input hidden name="field" value="certificate_pos_y"/>
                <div class="flex-column flex-md-row d-flex justify-content-between">
                    <div
                        class="mt-3 flex-column flex-md-row d-flex justify-content-start col-12 col-md-9 align-items-stretch">
                        <label class="col-11 col-md-3" for="certificate_pos_y">Distancia del borde superior</label>
                        <input style="height:80%;" class="col-11 col-md-8" type="text" name="certificate_pos_y" value="<?php echo e($information->certificate_pos_y); ?>">
                    </div>
                    <button class="mt-2 btn btn-primary col-11 col-md-3" type="submit">Cambiar distancia del borde superior (1px, 1rem, 1inch, 1cm)</button>
                </div>
                <?php $__errorArgs = ['certificate_pos_y'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="text-danger"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/information/edit.blade.php ENDPATH**/ ?>