<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <?php
        $lesson_now = $course->lessons[Auth::user()->lesson_now];

    ?>
    <div class="p-2 mx-auto mt-5 max-w-7xl">
        <h1 class="text-3xl font-bold">Certificación</h1>


        <div class="grid w-full grid-cols-1 gap-6 my-5 sm:grid-cols-4">
            
            <article class="flex flex-col w-full col-span-1 p-5 bg-white rounded-lg sm:col-span-3">
                    <h1 class="my-2 text-3xl font-bold"><?php echo e($information->end_title); ?></h1>
                    <br>
                    <p class="mt-5"><?php echo e($information->end_text_1); ?></p>
                    <p class="mt-5"><?php echo e($information->end_text_2); ?></p>
                    <a class="w-full p-2 mt-10 font-bold bg-purple-300 border rounded-lg" method="POST" target="_blank" href=<?php echo e(route('content.generatecertification')); ?>>
                        <button class="text-left">Descargar certificado</button>
                    </a>
            </article>






            

            <div class="flex flex-col w-full col-span-1 p-2 overflow-hidden text-xs bg-white rounded-lg">
                <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="my-2" x-data="{ open: false }">
                        <h3 class="p-2 font-bold text-white bg-blue-600 rounded-lg" x-on:click="open = ! open">
                            <?php echo e($key + 1); ?>. <?php echo e($section->name); ?> <i class="fas fa-caret-down"></i></h3>
                        <div class="w-full" x-show="open">
                            <?php if($section->lessons_count == 0): ?>
                                <div class="w-full p-2 mt-2 border rounded-lg">
                                    No hay lecciones
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($lesson->section_id == $section->id): ?>
                                        <form
                                            class="w-full rounded-lg p-2 mt-2 border <?php echo e($key <= Auth::user()->lesson_max ? 'text-black' : 'text-gray-400'); ?> <?php echo e($key == Auth::user()->lesson_now? 'bg-blue-400' : 'bg-blue-200'); ?>"
                                            method="POST" action=<?php echo e(route('content.updatespecific')); ?>>
                                            <?php echo csrf_field(); ?>
                                            <input value=<?php echo e($key); ?> name="lesson" hidden>
                                            <button class="text-left" type="submit">L.<?php echo e($key+1); ?> - <?php echo e($lesson->name); ?></button>
                                        </form>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="my-5">
                        No hay secciones aún
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->lesson_max==$course->lessons_count-1): ?>
                    <a href="<?php echo e(route('content.showevaluation')); ?>" class="w-full p-2 my-2 font-bold text-black bg-yellow-300 rounded-lg">Evaluacion final</a>
                <?php endif; ?>
                <?php if(Auth::user()->usability==1): ?>
                    <a href="<?php echo e(route('content.showcertification')); ?>" class="w-full p-2 my-2 font-bold text-black bg-purple-300 rounded-lg">Certificado</a>
                <?php endif; ?>
            </div>


    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/content/certification.blade.php ENDPATH**/ ?>