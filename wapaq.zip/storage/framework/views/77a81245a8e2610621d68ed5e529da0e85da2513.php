<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="flex flex-col w-full h-full mx-auto my-auto lg:items-start max-w-7xl lg:flex-row">
        <section class="flex flex-col w-11/12 min-h-screen p-6 mx-auto my-10 bg-white rounded-lg shadow-xl">
            <h1 class="text-3xl font-bold">
                Créditos
            </h1>
            <?php $__empty_1 = true; $__currentLoopData = $credits; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $credit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <article
                    class="flex flex-col items-start justify-start p-6 mt-6 border-4 border-black border-dashed rounded-lg sm:flex-row min-w-90">
                    <img class="object-center w-48 h-48 rounded-full sm:mr-6" src="<?php echo e($credit->picture); ?>"
                        alt="<?php echo e($credit->name); ?>" />
                    <div>
                        <h2 class="text-2xl font-bold">
                            <?php echo e($credit->name); ?>

                        </h2>
                        <h3 class="text-xl font-bold">
                            <?php echo e($credit->role); ?>

                        </h3>
                        <p class="mt-3">
                            <?php echo e($credit->description); ?>

                        </p>
                    </div>
                </article>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <article
                    class="flex flex-col items-start justify-start p-6 mt-6 border-4 border-black border-dashed rounded-lg sm:flex-row min-w-90">
                    No hay creditos
                </article>
            <?php endif; ?>

        </section>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/credits.blade.php ENDPATH**/ ?>