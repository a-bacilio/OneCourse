<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
    <h1> Administrar Lecciones</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="card">
        <div class="card-header">
            <h1 class="fs-4">
                <a href="<?php echo e(route('admin.lesson.index')); ?>">
                    <i class="fas fa-door-open"></i>
                </a> Editando: <?php echo e($lesson->name); ?>

            </h1>
            <h6><?php echo e($lesson->description); ?></h6>
        </div>
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.lesson.update')); ?>">
                <?php echo csrf_field(); ?>
                <input type="text" name="id" value="<?php echo e($lesson->id); ?>" hidden>
                <div class="form-group">
                    <label for="name">Nombre nuevo</label>
                    <input type="text" class="form-control" name="name" placeholder="Coloque el nombre" required value="<?php echo e($lesson->name); ?>">
                </div>
                <div class="input-group">
                    <span class="input-group-text">Descripción nueva</span>
                    <textarea class="form-control" name="description" aria-label="With textarea"><?php echo e($lesson->description); ?></textarea>
                </div>
                <button type="submit" class="mt-4 btn btn-primary">Actualizar</button>
            </form>
        </div>
        <?php if (isset($component)) { $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4 = $component; } ?>
<?php $component = $__env->getContainer()->make(Illuminate\View\AnonymousComponent::class, ['view' => 'jetstream::components.validation-errors','data' => ['class' => 'mt-4 mb-4']]); ?>
<?php $component->withName('jet-validation-errors'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes(['class' => 'mt-4 mb-4']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4)): ?>
<?php $component = $__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4; ?>
<?php unset($__componentOriginalc254754b9d5db91d5165876f9d051922ca0066f4); ?>
<?php endif; ?>

    </div>

    <h3>Editar recursos</h3>
    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-edit-lesson',['lesson_id'=>$lesson_id])->html();
} elseif ($_instance->childHasBeenRendered('BCaSObE')) {
    $componentId = $_instance->getRenderedChildComponentId('BCaSObE');
    $componentTag = $_instance->getRenderedChildComponentTagName('BCaSObE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BCaSObE');
} else {
    $response = \Livewire\Livewire::mount('admin-edit-lesson',['lesson_id'=>$lesson_id]);
    $html = $response->html();
    $_instance->logRenderedChild('BCaSObE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

    <h3>Eliminar</h3>
    <div class="card">
        <div class="card-body">
            <form method="POST" action="<?php echo e(route('admin.lesson.destroy')); ?>">
                <?php echo csrf_field(); ?>
                <label>Escriba "<?php echo e($lesson->id); ?>" para confirmar eliminacion </label>
                <input type="text" name="id">
                <input type="text" name="ids" hidden value="<?php echo e($lesson->id); ?>">
                <br>
                <button type="submit" class="mt-4 btn btn-danger">Eliminar</button>
            </form>
        </div>
    </div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    <script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/lesson/edit.blade.php ENDPATH**/ ?>