<div class="card">
    <div class="card-header">
        <a href="#">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-down"></i> Descargar
            </button>
        </a>
    </div>
    <div class="card-header">
        <input wire:keydown:"limpiar_page" wire:model="search" class="form-control w-100"
            placeholder="Escriba un nombre ...">
    </div>
    <div class="card-body">
        <table class="table table-dark">
            <thead>
                <tr>
                    <th class="col-1" scope="col">id</th>
                    <th class="col-1">Nombre</th>
                    <th class="col-1">Correo</th>
                    <th class="col-1">Género</th>
                    <th class="col-1">Fecha de Nacimiento</th>
                    <th class="col-1">Nivel de educacion</th>
                    <th class="col-1">Estado civil</th>
                    <th class="col-1">ocupacion</th>
                    <th class="col-1">Pais</th>
                    <th class="col-1">Provincia</th>
                    <th class="col-1">Distrito</th>
                    <th class="col-1">Tuvo familiar con covid</th>
                    <th class="col-1">Cuidado propio</th>
                    <th class="col-1">Cudiado Profesional</th>
                    <th class="col-1">Leccion máxima</th>
                    <th class="col-1">Dio evaluacion?</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <td><?php echo e($user->id); ?></td>
                        <td><?php echo e($user->name); ?></td>
                        <td><?php echo e($user->email); ?></td>
                        <td><?php echo e($user->gender); ?></td>
                        <td><?php echo e($user->birth_date); ?></td>
                        <td><?php echo e($user->education_level); ?></td>
                        <td><?php echo e($user->civil_status); ?></td>
                        <td><?php echo e($user->occupation); ?></td>
                        <td><?php echo e($user->residence_state); ?></td>
                        <td><?php echo e($user->residence_province); ?></td>
                        <td><?php echo e($user->residence_district); ?></td>
                        <td><?php echo e($user->covid_family); ?></td>
                        <td><?php echo e($user->caretaker_you); ?></td>
                        <td><?php echo e($user->caretaker_pro); ?></td>
                        <td><?php echo e($user->lesson_max); ?></td>
                        <td><?php echo e($user->usability); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr class="col-span-2">
                        <td colspan="2"> No hay elementos</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
        <?php echo e($users->links()); ?>

    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-data.blade.php ENDPATH**/ ?>