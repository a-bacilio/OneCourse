

<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1> Referencias</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-credit')->html();
} elseif ($_instance->childHasBeenRendered('zasiTDs')) {
    $componentId = $_instance->getRenderedChildComponentId('zasiTDs');
    $componentTag = $_instance->getRenderedChildComponentTagName('zasiTDs');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('zasiTDs');
} else {
    $response = \Livewire\Livewire::mount('admin-credit');
    $html = $response->html();
    $_instance->logRenderedChild('zasiTDs', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/credit/index.blade.php ENDPATH**/ ?>