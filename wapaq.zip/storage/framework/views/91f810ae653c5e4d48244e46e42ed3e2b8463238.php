<div class="card">
    <div class="card-body">
        <span class="">Recursos en la lección</span>
        <table class="table table-dark">
            <thead>
                <tr>
                    <th class="col-1" scope="col">#</th>
                    <th scope="col-2">Name</th>
                    <th scope="col-1">Retire</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($resource->id); ?></th>
                        <td><?php echo e($resource->name); ?></td>
                        <td>
                            <i wire:click="removeResource(<?php echo e($resource->id); ?>)" style="color: yellow; margin:auto"
                                class="fas fa-arrow-circle-down"></i>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            No hay recursos
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <div class="card-body">
        <span class="">Recursos disponibles</span>
        <table class="table table-dark">
            <thead>
                <tr>
                    <th class="col-1" scope="col">#</th>
                    <th scope="col-2">Name</th>
                    <th scope="col-1">Retire</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $resources_nolesson; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <tr>
                        <th scope="row"><?php echo e($resource->id); ?></th>
                        <td><?php echo e($resource->name); ?></td>
                        <td>
                            <i wire:click="addResource(<?php echo e($resource->id); ?>)" style="color: green; margin:auto"
                                class="fas fa-arrow-circle-up"></i>
                        </td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <tr>
                        <td colspan="3">
                            No hay recursos
                        </td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-edit-lesson.blade.php ENDPATH**/ ?>