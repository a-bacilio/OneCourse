<?php echo e($slot); ?>: <?php echo e($url); ?>

<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/button.blade.php ENDPATH**/ ?>