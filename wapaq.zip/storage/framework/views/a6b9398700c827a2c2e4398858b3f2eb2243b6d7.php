

<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1> Referencias</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-question')->html();
} elseif ($_instance->childHasBeenRendered('H9fgQOU')) {
    $componentId = $_instance->getRenderedChildComponentId('H9fgQOU');
    $componentTag = $_instance->getRenderedChildComponentTagName('H9fgQOU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('H9fgQOU');
} else {
    $response = \Livewire\Livewire::mount('admin-question');
    $html = $response->html();
    $_instance->logRenderedChild('H9fgQOU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script src="//unpkg.com/alpinejs" defer></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/question/index.blade.php ENDPATH**/ ?>