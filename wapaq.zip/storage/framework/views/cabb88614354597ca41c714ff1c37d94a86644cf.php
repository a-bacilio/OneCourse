<div class="card">
    <div class="card-header">
        <a href="<?php echo e(route('admin.section.create')); ?>">
            <button type="button" class="btn btn-primary">
                <i class="fas fa-plus"></i> Añadir Sección
            </button>
        </a>
    </div>
    <div class="card-header">
        <input wire:keydown:"limpiar_page" wire:model="search" class="form-control w-100" placeholder="Escriba un nombre ...">
    </div>
    <div class="card-body">
        <table class="table table-dark">
            <thead>
              <tr>
                <th class="col-1" scope="col">#</th>
                <th scope="col-2">Name</th>
                <th scope="col-2">En uso</th>
                <th scope="col-1">Editar</th>
              </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <th scope="row"><?php echo e($section->id); ?></th>
                    <td><?php echo e($section->name); ?></td>
                    <td><?php echo e($section->course_id==1?"Si":"No"); ?></td>
                    <td>
                        <a href="section/edit/<?php echo e($section->id); ?>" style="background-color:#00000000; border:none;" type="submit"><i class="fas fa-pencil-alt" style="color:yellow;"></i></a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
          <?php echo e($sections->links()); ?>

    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-section.blade.php ENDPATH**/ ?>