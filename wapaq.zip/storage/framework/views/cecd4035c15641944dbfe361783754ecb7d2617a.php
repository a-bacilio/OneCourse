

<?php $__env->startSection('title', 'Panel Admin'); ?>

<?php $__env->startSection('content_header'); ?>
  <h1> Administrar Secciones del curso</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin-section')->html();
} elseif ($_instance->childHasBeenRendered('L1miyRz')) {
    $componentId = $_instance->getRenderedChildComponentId('L1miyRz');
    $componentTag = $_instance->getRenderedChildComponentTagName('L1miyRz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('L1miyRz');
} else {
    $response = \Livewire\Livewire::mount('admin-section');
    $html = $response->html();
    $_instance->logRenderedChild('L1miyRz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>


<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
  <script>console.log('Hi');</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('adminlte::page', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/admin/section/index.blade.php ENDPATH**/ ?>