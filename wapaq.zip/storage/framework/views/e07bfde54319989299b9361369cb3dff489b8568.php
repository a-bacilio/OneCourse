<div class="card">
    <div class="card-body">
        <form class="d-flex flex-column"
            wire:submit.prevent="change_welcome_title">
            <div  class="flex-column flex-sm-row d-flex justify-content-between">
                <div class="mt-3 flex-column flex-sm-row d-flex justify-content-start col-12 col-sm-9 align-items-stretch">
                    <label class="col-11 col-sm-3" for="welcome_title_new">Mensaje de bienvenida</label>
                    <input style="height:80%;" class="col-11 col-sm-8" type="text" name="welcome_title_new" wire:model="welcome_title_new">
                </div>
                <button  type="button" class="mt-2 btn btn-primary col-11 col-sm-3" type="submit">Cambiar mensaje de bienvenida</button>
            </div>
            <?php $__errorArgs = ['welcome_title_new'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span class="error"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        </form>
    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/livewire/admin-edit-information.blade.php ENDPATH**/ ?>