<?php if (isset($component)) { $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\AppLayout::class, []); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php $component->withAttributes([]); ?>
    <div class="p-2 mx-auto mt-5 max-w-7xl">
        <?php if($course->lessons_count>0): ?>
        <h1 class="text-3xl font-bold">Contenidos</h1>
        <h2>Contenido <i class="fas fa-greater-than"></i> <?php echo e($course->name); ?> <i class="fas fa-greater-than"></i>
            <?php echo e($lesson_now->section->name); ?> <i class="fas fa-greater-than"></i>
            <?php echo e($lesson_now->name); ?> </h2>

        <div class="grid w-full grid-cols-1 gap-6 my-5 sm:grid-cols-4">
            
            <article class="w-full col-span-1 p-2 bg-white rounded-lg sm:col-span-3">
                <h3 class="my-4 text-2xl font-bold">
                    Seccion
                    <?php echo e($lesson_now->section->id); ?>.
                    <br>
                    L<?php echo e(Auth::user()->lesson_now + 1); ?>.
                    <?php echo e($lesson_now->name); ?>

                    <h3>
                        <p>
                            <?php echo e($lesson_now->description); ?>

                        </p>

                        <?php if($lesson_now->resources_count == 0): ?>
                            <p> Este lección no tiene recursos</p>
                        <?php else: ?>
                            <?php $__empty_1 = true; $__currentLoopData = $resources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $resource): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <?php if($resource->lesson_id == $lesson_now->id): ?>
                                    <div class="mt-5">
                                        <div class="p-4 mx-2 mt-5 rounded-lg bg-sky-200"><?php echo e($resource->name); ?></div>
                                        <div class="">
                                            <?php if($resource->type == 'image'): ?>
                                                <img class="mx-auto my-3"
                                                    src="<?php echo e(asset($resource->image->url)); ?>" />
                                            <?php elseif($resource->type == 'video'): ?>
                                                <div class="flex flex-row justify-center w-full my-3">
                                                    <?php echo $resource->online_video->iframe; ?></div>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <p> Este lección no tiene recursos</p>
                            <?php endif; ?>
                        <?php endif; ?>

                        <div class="flex flex-row justify-between">
                            <?php if($lesson_now->id > 1): ?>
                                <form class="" method="POST" action=<?php echo e(route('content.update')); ?>>
                                    <?php echo csrf_field(); ?>
                                    <input value="previous" name="buttonaction" hidden>
                                    <button class="p-2 text-white bg-blue-700 rounded-lg"
                                        type="submit">Anterior</button>
                                </form>
                            <?php endif; ?>
                            <?php if($lesson_now->id < $course->lessons_count): ?>
                                <form class="" method="POST" action=<?php echo e(route('content.update')); ?>>
                                    <?php echo csrf_field(); ?>
                                    <input value="next" name="buttonaction" hidden>
                                    <button class="p-2 text-white bg-blue-900 rounded-lg"
                                        type="submit">Siguiente</button>
                                </form>
                            <?php endif; ?>
                        </div>




            </article>

            

            <div class="flex flex-col w-full col-span-1 p-2 overflow-hidden text-xs bg-white rounded-lg">
                <?php $__empty_1 = true; $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                    <div class="my-2" x-data="{ open: false }">
                        <h3 class="p-2 font-bold text-white bg-blue-600 rounded-lg" x-on:click="open = ! open">
                            <?php echo e($key + 1); ?>. <?php echo e($section->name); ?> <i class="fas fa-caret-down"></i></h3>
                        <div class="w-full" x-show="open">
                            <?php if($section->lessons_count == 0): ?>
                                <div class="w-full p-2 mt-2 border rounded-lg">
                                    No hay lecciones
                                </div>
                            <?php else: ?>
                                <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <?php if($lesson->section_id == $section->id): ?>
                                        <form
                                            class="w-full rounded-lg p-2 mt-2 border <?php echo e($key <= Auth::user()->lesson_max ? 'text-black' : 'text-gray-400'); ?> <?php echo e($key == Auth::user()->lesson_now ? 'bg-blue-400' : 'bg-blue-200'); ?>"
                                            method="POST" action=<?php echo e(route('content.updatespecific')); ?>>
                                            <?php echo csrf_field(); ?>
                                            <input value=<?php echo e($key); ?> name="lesson" hidden>
                                            <button class="text-left" type="submit">L.<?php echo e($key + 1); ?> -
                                                <?php echo e($lesson->name); ?></button>
                                        </form>
                                    <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <?php endif; ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                    <div class="my-5">
                        No hay secciones aún
                    </div>
                <?php endif; ?>
                <?php if(Auth::user()->lesson_max == $course->lessons_count - 1): ?>
                    <a href="<?php echo e(route('content.showevaluation')); ?>"
                        class="w-full p-2 my-2 font-bold text-black bg-yellow-300 rounded-lg">Evaluacion final</a>
                <?php endif; ?>
                <?php if(Auth::user()->usability == 1): ?>
                    <a href="<?php echo e(route('content.showcertification')); ?>"
                        class="w-full p-2 my-2 font-bold text-black bg-purple-300 rounded-lg">Certificado</a>
                <?php endif; ?>
            </div>

        </div>

        <?php else: ?>
            No hay lecciones en este curso
        <?php endif; ?>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da)): ?>
<?php $component = $__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da; ?>
<?php unset($__componentOriginal8e2ce59650f81721f93fef32250174d77c3531da); ?>
<?php endif; ?>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/content/index.blade.php ENDPATH**/ ?>