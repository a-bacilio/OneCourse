<div class="flex flex-col items-center pt-1 mx-1 my-5 sm:justify-center sm:pt-0 bg-cyan-200">
    <div>
        <?php echo e($logo); ?>

    </div>

    <div class="w-full max-w-6xl px-6 py-4 mx-auto mt-6 overflow-hidden bg-white shadow-md sm:rounded-lg">
        <?php echo e($slot); ?>

    </div>
</div>
<?php /**PATH F:\0001 Anthony\0002 Proyectos\0004 Cuenta Propia\0067 Wapa\wapaq\resources\views/vendor/jetstream/components/authentication-card.blade.php ENDPATH**/ ?>